package sample.example.glndetect;

import java.util.ArrayList;
import java.util.List;

public class ConvertPosition {
    private final double[][] pts;
    private final double Width;
    private final double Height;
    private final double[] base_pt;
    private final double[] vector1;
    private final double[] vector2;
    private final double[] vector3;
    private final double[] vector4;
    ConvertPosition(double[][] points, double width, double height, double[] base){
        this.pts = points;
        Width = width;
        Height = height;
        this.base_pt = base;
        vector1 = vectorM(this.pts[1],this.pts[0]);
        vector2 = vectorM(this.pts[2],this.pts[1]);
        vector3 = vectorM(this.pts[2],this.pts[3]);
        vector4 = vectorM(this.pts[3],this.pts[0]);
    }
    public double[] vectorX(double[]vector,double a){return new double[]{vector[0]*a,vector[1]*a};}
    public double[] vectorP(double[]vector1,double[]vector2){return new double[]{vector1[0]+vector2[0],vector1[1]+vector2[1]};}
    public double[] vectorM(double[]vector1,double[]vector2){return new double[]{vector1[0]-vector2[0],vector1[1]-vector2[1]};}
    public double dist(double[]vector){return Math.sqrt(Math.pow(vector[0],2)-Math.pow(vector[1],2));}

    public double[] convert(double[] pos){
        double[] pos1 = vectorX(vector1,pos[0]/Width);
        double[] pos2 = vectorP(vector1,vectorX(vector2,pos[1]/Height));
        double[] pos3 = vectorP(vector4,vectorX(vector3,pos[0]/Width));
        double[] pos4 = vectorX(vector4,pos[1]/Height);
        double line1_a = vectorM(pos1,pos3)[1]/vectorM(pos1,pos3)[0];
        double line1_b = pos1[1]-pos1[0]*line1_a;
        double line2_a = vectorM(pos2,pos4)[1]/vectorM(pos2,pos4)[0];
        double line2_b = pos2[1]-pos2[0]*line2_a;
        Object[] result = systemOfEquations(new double[][]{new double[]{line1_a,-1,-line1_b},new double[]{line2_a,-1,-line2_b}}).toArray();
        double[] result2 = new double[result.length];
        for (int i = 0;i<result.length;i++){
            result2[i] = (double)result[i];
        }
        return vectorP(result2,base_pt);
    }
    public List<Double> systemOfEquations(final double[][] coefficientMatrix) {
        List<Double> result = new ArrayList<>();
        double[][] matrix = coefficientMatrix;
        int n = matrix.length;
        int m = matrix[0].length;

        for (int k = 0; k < n; k++) {
            double p = matrix[k][k];

            for (int j = k; j < m; j++) {
                matrix[k][j] = matrix[k][j]/p;
            }

            for (int i = 0; i < n; i++) {
                if (i != k) {
                    double d = matrix[i][k];

                    for (int j = k; j < m; j++) {
                        matrix[i][j] = matrix[i][j] - d * matrix[k][j];
                    }
                }
            }
        }

        for (int i = 0; i < n; i++) {
            result.add(matrix[i][n]);
        }

        return result;
    }
}
