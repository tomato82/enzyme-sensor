package sample.example.glndetect;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collection;

import sample.example.glndetect.R;

public class MainActivity extends AppCompatActivity {
    int kinds_num = 1;
    TableRow tableLabel;
    TableLayout mainTable;
    String[] Items;
    int ID = 1001;
    ImageButton selectingView;
    TextView selectingText;
    String detectingTag;
    double aspect;
    int cellWidth;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.tableLabel = findViewById(R.id.label_row);
        this.mainTable = findViewById(R.id.mainTable);
        this.Items = getResources().getStringArray(R.array.example_kinds);
        String aspectString = getResources().getString(R.string.aspect);
        aspect = Double.parseDouble(aspectString);
        cellWidth = getResources().getInteger(R.integer.cell_width);

    }
    public void kinds_add(View v) {
        Spinner label = new Spinner(this);
        label.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,this.Items));
        label.setPrompt(getString(R.string.example_prom));
        this.tableLabel.addView(label,this.tableLabel.getChildCount()-1);
        label.setMinimumWidth(cellWidth);
        for (int i = 1;i<this.mainTable.getChildCount();i++){
            TableRow row = (TableRow) this.mainTable.getChildAt(i);
            column_add(row);
        }
        this.kinds_num ++;
    }
    public void example_add(View v) {
        TableRow row = new TableRow(this);
        row.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT,TableLayout.LayoutParams.MATCH_PARENT));
        row.setGravity(Gravity.CENTER_HORIZONTAL);
        EditText tag = new EditText(this);
        tag.setText(String.format("tag%d",this.mainTable.getChildCount()));
        row.addView(tag);
        TextView result = new TextView(this);
        result.setText("select result type");
        result.setGravity(Gravity.CENTER);
        row.addView(result);
        for (int i = 0;i<this.kinds_num;i++) {
            column_add(row);
        }
        this.mainTable.addView(row);
    }
    public void column_add(TableRow row){
        int column = row.getChildCount()-1;
        Spinner tag = (Spinner)tableLabel.getChildAt(column);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        row.addView(layout,column);
        ImageButton image = new ImageButton(this);
        image.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
        TextView text = new TextView(this);
        text.setGravity(Gravity.CENTER);
        text.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));
        text.setText("select picture");
        image.setMinimumHeight((int)Math.floor(tag.getWidth()*aspect));
        image.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent i = new Intent(MainActivity.this,SubActivity.class);
                i.putExtra("tag",detectingTag);
                startActivityForResult(i,ID);
                selectingView = (ImageButton) view;
                selectingText = text;
                detectingTag = (String)tag.getSelectedItem();
                System.out.println(detectingTag);
            }
        });
        layout.addView(image);
        layout.addView(text);
    }
    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        System.out.println(requestCode==ID);
        System.out.println(resultCode);
        if(requestCode == ID&&resultCode==RESULT_OK){
            Bitmap result = (Bitmap)data.getParcelableExtra("result");
            result = Bitmap.createScaledBitmap(result,selectingView.getWidth(),(int)Math.floor(selectingView.getWidth()*aspect),false);
            selectingView.setImageBitmap(result);
            selectingText.setText(bitmapToResult(result));
        }
    }
    private static float[] getHSV(int colorInt){
        float[] result = new float[3];
        Color.colorToHSV(colorInt,result);
        return result;
    }
    private int getIdFromTag(String tag){
        int id;
        switch (tag){
            case "グルタミン酸":
                id = R.string.glu;
                break;
            case "グルコース":
                id = R.string.glc;
                break;
            default:
                id = 0;
        }
        return id;
    }
    private String bitmapToResult(Bitmap bmp){
        int id = getIdFromTag(detectingTag);
        if (id == 0){
            return getResources().getString(R.string.error);
        }else {
            float bias = Float.parseFloat(getResources().getString(id));
            System.out.println(bias);
            int width = bmp.getWidth();
            int height = bmp.getHeight();
            float red = getRed(bmp,0, width / 16,  0, height);
            float green = getGreen(bmp, 0,width / 16,0, height);
            float blue = getGreen(bmp, 0,width / 16, 0, height);
            float whiteRed = getRed(bmp, width / 16,width / 5 * 4, 0, height);
            float whiteGreen = getGreen(bmp, width / 16,width / 5 * 4, 0, height);
            float whiteBlue = getBlue(bmp, width / 16,height / 5 * 4, 0, height);
            float correctedRed = red / whiteRed;
            float correctedGreen = green / whiteGreen;
            float correctedBlue = blue / whiteBlue;
            float maxValue = Math.max(correctedRed, Math.max(correctedBlue, correctedGreen));
            float minValue = Math.min(correctedRed, Math.min(correctedBlue, correctedGreen));
            return Float.toString((maxValue - minValue) / maxValue * bias);
        }
    }
    private float getRed(Bitmap bmp,int minX,int maxX,int minY,int maxY){
        Collection<Float> sList = new ArrayList<>();
        for (int x = minX;x<maxX;x++){
            for (int y = minY;y<maxY;y++){
                sList.add((float)Color.red(bmp.getPixel(x,y))*100);
            }
        }
        int sSum = 0;
        for (float s:sList){
            sSum += s;
        }
        return sSum/sList.size();

    }
    private float getBlue(Bitmap bmp,int minX,int maxX,int minY,int maxY){
        Collection<Float> sList = new ArrayList<>();
        for (int x = minX;x<maxX;x++){
            for (int y = minY;y<maxY;y++){
                sList.add((float)Color.blue(bmp.getPixel(x,y))*100);
            }
        }
        int sSum = 0;
        for (float s:sList){
            sSum += s;
        }
        return sSum/sList.size();

    }
    private float getGreen(Bitmap bmp,int minX,int maxX,int minY,int maxY){
        Collection<Float> sList = new ArrayList<>();
        for (int x = minX;x<maxX;x++){
            for (int y = minY;y<maxY;y++){
                sList.add((float)Color.green(bmp.getPixel(x,y))*100);
            }
        }
        int sSum = 0;
        for (float s:sList){
            sSum += s;
        }
        return sSum/sList.size();

    }
}
