package sample.example.glndetect;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.ImageView;

public class PosSelect extends SurfaceView{
    private boolean touchMode = false;
    private double[][] pts = new double[4][2];
    public Bitmap image;
    private Paint p;
    private Paint circleP;
    private int onDrag = -1;
    private final double dist_flag = 30;
    private final double radius = 15;
    private final int resultWidth = 500;
    private final int resultHeight = 50;
    private float startDist;
    private float scale = 1;
    private float startX = 0;
    private float startY = 0;
    public ImageView preview;
    public double maxWidth;
    public double maxHeight;
    public double height;
    public double aspect;
    public Bitmap resultImage;
    public float tag;
    private Bitmap baseImage;
    private float[] beforePts = new float[2];
    public PosSelect(Context context) {
        super(context);
        initialize();
    }
    public PosSelect(Context context, AttributeSet attrs) {
        super(context,attrs);
        initialize();
    }
    public PosSelect(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context,attrs,defStyleAttr);
        initialize();
    }
    public void onTouch(SurfaceHolder holder,MotionEvent event){
        pts[this.onDrag] = new double[]{event.getX(),event.getY()};
        circleDraw(holder);
    }
    public void canvasInit(Canvas canvas){
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(image,0,0,null);
    }
    public void circleDraw(SurfaceHolder holder){
        Canvas canvas = holder.lockCanvas();
        canvasInit(canvas);
        for (int i = 0;i<4;i++){
            canvas.drawLine((float)pts[i][0],(float)pts[i][1],(float)pts[(i+1)%4][0],(float)pts[(i+1)%4][1],p);
            canvas.drawCircle((float)pts[i][0],(float)pts[i][1],(float)radius,circleP);
        }
        holder.unlockCanvasAndPost(canvas);

    }
    public static double[] ConvertPtsToDist(double[] pt1,double[][] pts){
        double[] dist = new double[pts.length];
        for (int i = 0;i<pts.length;i++){
            double[] pt = pts[i];
            dist[i] = Math.sqrt(Math.pow(pt[0]-pt1[0],2)+Math.pow(pt[1]-pt1[1],2));
        }
        return dist;
    }
    public void previewResult(ImageView imageView){
        double previewWidth = Math.floor(imageView.getWidth());
        double previewHeight = Math.floor(imageView.getWidth());
        System.out.println("previewResult");
        Bitmap result = Bitmap.createBitmap((int)previewWidth,(int)previewHeight,Bitmap.Config.ARGB_8888);
        ConvertPosition convPos = new ConvertPosition(this.pts,previewWidth,previewHeight,this.pts[0]);
        for (int x = 0;x<previewWidth;x++){
            for (int y = 0;y<previewHeight;y++) {
                double[] convertedPos = convPos.convert(new double[]{x,y});
                result.setPixel(x,y,this.image.getPixel((int)convertedPos[0],(int)convertedPos[1]));
            }
        }
        Matrix image_mat = new Matrix();
        float[] loss = new float[]{0,0,0,0};
        image_mat.postRotate(90);
        for (int i = 0;i<4;i++) {
            int maxX = (int)Math.floor(result.getWidth()/5);
            int maxY = (int)Math.floor(result.getHeight());
            for (int x = 0; x < maxX; x++) {
                for (int y = 0; y < maxY; y++) {
                    int colorInt = result.getPixel(x,y);
                    loss[i] += getHSV(colorInt)[0];
                }
            }
            result = Bitmap.createBitmap(result,0,0,result.getWidth(),result.getHeight(),image_mat,false);
            loss[i] = Math.abs((loss[i]/maxX/maxY)-145);
        }
        Matrix result_mat = new Matrix();
        result_mat.postRotate(90*argMin(loss));
        for (float l:loss){
            System.out.printf("%f ",l);
        }
        System.out.println(argMin(loss));
        result = Bitmap.createBitmap(result,0,0,result.getWidth(),result.getHeight(),result_mat,false);
        result = Bitmap.createScaledBitmap(result,(int)previewWidth,(int)Math.floor(previewWidth*aspect),false);
        imageView.setImageBitmap(result);
        resultImage = result;
    }
    private static float[] getHSV(int colorInt){
        float[] result = new float[3];
        Color.colorToHSV(colorInt,result);
        return result;
    }
    private static int argMin(float[] array){
        float min_num = array[0];
        int result = 0;
        for (int i = 1;i<array.length;i++){
            if (array[i]<min_num){
                min_num = array[i];
                result = i;
            }
        }
        return result;
    }
    public void setImageBitmap(Bitmap bmp){
        double resizeScale;
        if (bmp.getWidth() >= bmp.getHeight()) {
            resizeScale = (double) getWidth() / bmp.getWidth();
        }
        else {
            resizeScale = (double) getWidth() / bmp.getHeight();
        }
        Bitmap result = Bitmap.createScaledBitmap(bmp,
                (int) (bmp.getWidth() * resizeScale),
                (int) (bmp.getHeight() * resizeScale),
                false);
        baseImage = result;
        image = result;
    }
    @Override
    public boolean onTouchEvent(MotionEvent event){
        if (event.getPointerCount()==1) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    double[] dist = ConvertPtsToDist(new double[]{event.getX(), event.getY()}, this.pts);
                    double min_dist = dist_flag;
                    for (int i = 0; i < dist.length; i++) {
                        double d = dist[i];
                        if (d < min_dist) {
                            min_dist = d;
                            this.onDrag = i;
                        }
                    }
                    if (this.onDrag != -1) {
                        onTouch(getHolder(), event);
                    }else{
                        beforePts[0] = event.getX();
                        beforePts[1] = event.getY();
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (this.onDrag != -1) {
                        onTouch(getHolder(), event);
                    }else{
                        float eventX = event.getX();
                        float eventY = event.getY();
                        startX -= (eventX-beforePts[0])/scale;
                        startY -= (eventY-beforePts[1])/scale;
                        beforePts[0] = eventX;
                        beforePts[1] = eventY;
                        updateImage();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    performClick();
                    touchMode = false;
                    if (this.onDrag != -1) {
                        onTouch(getHolder(), event);
                        previewResult(preview);
                        this.onDrag = -1;
                    }
                    break;
            }
        }else if (event.getPointerCount()==2){
            float[][] touchPoints = new float[2][2];
            for (int i = 0;i<2;i++){
                touchPoints[i][0] = event.getX(i);
                touchPoints[i][1] = event.getY(i);
            }
            if (touchMode) {
                float dist = getDist(touchPoints);
                System.out.printf("dist:%f",dist);
                scale *= dist/startDist;
                startDist = dist;
                updateImage();

            }else{
                System.out.println("DOWN");
                startDist = getDist(touchPoints);
                touchMode = true;
            }

        }
        return true;
    }
    private static float getDist(float[][] pos){
        return (float)Math.sqrt(Math.pow(pos[0][0]-pos[1][0],2)+Math.pow(pos[0][1]-pos[1][1],2));
    }
    public void initialize(){
        p = new Paint();
        p.setStrokeWidth(3);
        p.setColor(Color.CYAN);
        circleP = new Paint();
        circleP.setStrokeWidth(3);
        circleP.setColor(Color.CYAN);
        circleP.setStyle(Paint.Style.STROKE);
        getHolder().addCallback(
                new SurfaceHolder.Callback(){
                    public void surfaceChanged(SurfaceHolder holder,int format,int width,int height){}
                    public void surfaceCreated(SurfaceHolder holder){
                        onCreate(holder);
                    }
                    public void surfaceDestroyed(SurfaceHolder holder) {}
                }
        );
    }
    public void onCreate(SurfaceHolder holder){
        Canvas canvas = holder.lockCanvas();
        canvas.drawColor(Color.WHITE);
        holder.unlockCanvasAndPost(canvas);
        if (this.image == null) {
            setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.test));
        }
        maxWidth = image.getWidth();
        maxHeight = image.getHeight();
        pts[0] = new double[]{maxWidth/3,maxHeight/3};
        pts[1] = new double[]{maxWidth/3*2,maxHeight/3};
        pts[2] = new double[]{maxWidth/3*2,maxHeight/3*2};
        pts[3] = new double[]{maxWidth/3,maxHeight/3*2};
        circleDraw(holder);
        previewResult(preview);
    }
    @Override
    public boolean performClick(){
        super.performClick();
        return true;
    }
    public void updateImage(){
        startX = Math.min(Math.max(startX,0),baseImage.getWidth()*(1-1/scale));
        startY = Math.min(Math.max(startY,0),baseImage.getHeight()*(1-1/scale));
        Bitmap imageTrim = Bitmap.createBitmap(baseImage,(int)startX,(int)startY,(int)(baseImage.getWidth()/scale),(int)(baseImage.getHeight()/scale));
        image = Bitmap.createScaledBitmap(imageTrim,(int)maxWidth,(int)maxHeight,false);
        circleDraw(getHolder());
    }
}
